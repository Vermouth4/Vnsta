# vnata

A simple tool for Instagram control, web scraping, and user Instagram interaction using requests.

## Description

This library provides a set of tools to interact with Instagram, perform web scraping, and control a Telegram bot. It includes features such as random number generation, HTTP requests, and more.

## Installation

You can install the required dependencies using the following command:

```sh
pip install requests telebot bs4 instabot